# Expense Tracker (React + Vite)

Simple expense tracker built with React and LocalStorage.

## Quick start

1. Make sure you have Node.js (v16+) and npm installed.
2. Extract the project.
3. In terminal, run:

```bash
cd expense-tracker
npm install
npm run dev
```

4. Open the URL shown by Vite (usually http://localhost:5173).

## Features

- Add income and expense transactions
- View balance, totals, and history
- Persists data to localStorage

## Notes

- This project uses Vite + React. If you prefer Create React App, you can adapt the files.