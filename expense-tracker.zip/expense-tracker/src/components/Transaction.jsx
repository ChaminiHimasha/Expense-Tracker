import React, { useContext } from 'react'
import { GlobalContext } from '../context/GlobalState'

export default function Transaction({ transaction }){
  const { deleteTransaction } = useContext(GlobalContext)
  const sign = transaction.amount < 0 ? 'minus' : 'plus'
  return (
    <div className={['transaction', sign].join(' ')}>
      <div>
        <strong>{transaction.text}</strong>
        <div style={{fontSize:12, color:'#666'}}>${transaction.amount.toFixed(2)}</div>
      </div>
      <div>
        <button className="delete-btn" onClick={() => deleteTransaction(transaction.id)}>✖</button>
      </div>
    </div>
  )
}