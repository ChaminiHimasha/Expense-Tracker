import React, { createContext, useReducer, useEffect } from 'react'

const initialState = {
  transactions: []
}

const LocalStorageKey = 'expense-tracker-data'

if (typeof window !== 'undefined') {
  const stored = window.localStorage.getItem(LocalStorageKey)
  if (stored) {
    try {
      initialState.transactions = JSON.parse(stored)
    } catch(e){
      initialState.transactions = []
    }
  }
}

export const GlobalContext = createContext(initialState)

function AppReducer(state, action){
  switch(action.type){
    case 'ADD_TRANSACTION':
      return {
        ...state,
        transactions: [action.payload, ...state.transactions]
      }
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter(t => t.id !== action.payload)
      }
    default:
      return state
  }
}

export const GlobalProvider = ({ children }) => {
  const [state, dispatch] = useReducer(AppReducer, initialState)

  useEffect(() => {
    try {
      window.localStorage.setItem(LocalStorageKey, JSON.stringify(state.transactions))
    } catch(e){}
  }, [state.transactions])

  function deleteTransaction(id){
    dispatch({ type: 'DELETE_TRANSACTION', payload: id })
  }

  function addTransaction(transaction){
    dispatch({ type: 'ADD_TRANSACTION', payload: transaction })
  }

  return (
    <GlobalContext.Provider value={{
      transactions: state.transactions,
      deleteTransaction,
      addTransaction
    }}>
      {children}
    </GlobalContext.Provider>
  )
}